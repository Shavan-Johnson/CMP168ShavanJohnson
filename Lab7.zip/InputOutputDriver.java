import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class InputOutputDriver {
	public static void main(String[] args) throws IOException {
		//Chapter 12 File Input/Output
		/*
		 * So far, we've relied on user input from the terminal when we want the user to interact with our program or need some 
		 * more information from the user.
		 * 
		 * This can become cumbersome and sometimes near impossible if the program need to be fed, 
		 * say 1000 lines one by one. 
		 * 
		 * For this reason, users can input information into your program directly from files instead.
		 * 
		 * Luckily, reading from the keyboard and reading from a file follow a similar flow. We use a Scanner object to 
		 * read through our file but instead of passing in System.in as a param, we pass in the file or FileInputStream.
		 */
		
		/*TODO: Create a new FileInputStream instance and pass it in as a parameter to a Scanner object.
		 * Print out the contents of the file as long as there are lines to print. 
		 * */
		
		FileInputStream fileStream = null;
		Scanner scanner = null;
		System.out.println("Attempting to open file...");
		
		try {
			fileStream = new FileInputStream("games.txt");
			scanner = new Scanner(fileStream); //tells the compiler that we're getting the txt file as input.
			System.out.println("Input stream successfully opened. These were the contents: ");
			
			//i want this while to run as long as there are lines to consume
			while(scanner.hasNextLine()) {
				System.out.println(scanner.nextLine());
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} finally {
			if(fileStream != null && scanner != null) {
				fileStream.close();
				scanner.close();
			}
			System.out.println("Closed file stream and scanner...");
		}
		
		
		/* In the same way we can get input from a file, we can output to a file as well.
		 * 
		 * Output to a file requires the use of the PrintWriter and FileOutputStream classes.
		 * 
		 * Similar to input:
		 * 1. Open the file using a FileOutputStream instance
		 * 2. Create a PrintWriter instance with the FileOutputStream instance as param.
		 * 3. Add whatever content you need to add to the file.
		 * 4. Close the file after writing is finished.
		 * 
		 * 
		 * TODO: Output all odd integers from 0-20, all on separate lines to a new file names odd.txt.
		 * 
		 * */
		
		FileOutputStream fileOutput = null;
		PrintWriter outFS = null;
		
		try {
			fileOutput = new FileOutputStream("odd.txt");
			outFS = new PrintWriter(fileOutput);
			for(int i = 0; i < 10; i++) {
				outFS.println(i*2+1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(outFS != null && fileOutput != null) {
				//somehow order matters...
				outFS.close();
				fileOutput.close();
			}
			System.out.println("Closed file output stream and print writer...");
		}

		
		/* TODO: Append the next two games in the Jak Trilogy on two separate lines to the end of the existing file 'games.txt' 
		 * 
		 * */
		String[] moreGames = {"Jak 2,Playstation 2,2003,Naughty Dog", "Jak 3,Playstation 2,2004,Naughty Dog"};
		
		FileOutputStream fileOutput1 = null;
		PrintWriter outFS1 = null;
		
		try {
			fileOutput1 = new FileOutputStream("games.txt", true);
			outFS1 = new PrintWriter(fileOutput1);
			
			for(String element: moreGames) {
				outFS1.println(element);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(outFS1 != null && fileOutput1 != null) {
				//somehow order matters...
				outFS1.close();
				fileOutput1.close();
			}
			System.out.println("Closed file output stream and print writer...");
		}
		
		
		/* Typically, you'll want to do more than just print the contents of an input file to the terminal. Usually you'll
		 * create your own objects, or run some methods to do some other processing. 
		 * 
		 * 
		 * TODO: Using the games.txt file as input, create new VideoGame objects from each new line. 
		 * */
		
		FileInputStream fileStream2 = null;
		Scanner scanner2 = null;
		System.out.println("Attempting to open file...");
		
		try {
			fileStream2 = new FileInputStream("games.txt");
			scanner2 = new Scanner(fileStream2); //tells the compiler that we're getting the txt file as input.
			System.out.println("Input stream successfully opened. These were the contents: ");
			
			while(scanner2.hasNextLine()) {
				//this is where i need to process the input file + create my objects
				Scanner lineScan = new Scanner(scanner2.nextLine());
				lineScan.useDelimiter(",");
				String gameName = lineScan.next(); 
				String console = lineScan.next();
				int year = lineScan.nextInt();
				String company = lineScan.next();
				VideoGame newGame = new VideoGame(gameName, console, year, company);
				System.out.println(newGame.toString());	
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} finally {
			if(fileStream2 != null && scanner2 != null) {
				fileStream2.close();
				scanner2.close();
			}
			System.out.println("Closed file stream and scanner...");
		}
		
		

	}
}
