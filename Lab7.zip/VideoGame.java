public class VideoGame {
	public static int num = 0;
	private String console;
	private int releaseYear;
	private String company;
	private String name;
	
	public VideoGame() {
		console = "Generic";
		releaseYear = 0;
		company = "Generic";
		name = "Generic";
		num += 1;
	}
	
	public VideoGame(String name, String console, int releaseYear, String company) {
		this.console = console;
		this.releaseYear = releaseYear;
		this.company = company;
		this.name = name;
		num +=1;
	}
	
	public String toString() {
		return String.format("VIDEOGAME #%d: \n%s was released in %d for the %s by %s.\n", num, name, releaseYear, console, company);
	}
	
	
}
